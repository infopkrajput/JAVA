public class Main {
    public static void main(String[] args) {
        Str t1 = new Str();
        System.out.println(t1);
    }
}
