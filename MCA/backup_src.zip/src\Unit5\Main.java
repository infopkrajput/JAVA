public class Main{
	public static void main(String[] argvs){
		String a = "Hello";
        String b = "Hello";
		if(a.equals(b) == true){
            System.out.println("both strings are equal");
		}
        else{
            System.out.println("both strings are not equal");
        }
	}
}
