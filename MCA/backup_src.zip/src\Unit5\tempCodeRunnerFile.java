
    // BoxWeight now uses super to initialize its Box attributes.