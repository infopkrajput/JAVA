public class Str {
    private char []t = new char[20];
    Str(){
        this.t[0] = ' '; 
    }
    Str(String st){
         
    }
}
