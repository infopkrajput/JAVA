public class Parent {
    String display(int a)
    {
        String s = "Integer : " + a; 
        return s;
    }
}
