public class trim {
    public static void main(String[] args) {
        String s = "   Hello world   ";
        System.out.println(s);
        String n = s.trim();
        System.out.println(n);
    }
}
