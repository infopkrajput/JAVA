package Unit1.javadoc;

/**
 * The HelloWorld class implements an application that
 * simply prints "Hello, World!" to standard output.
 */
public class HelloWorld {
    /**
     * Main method that prints "Hello, World!".
     *
     * @param args not used
     */
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
