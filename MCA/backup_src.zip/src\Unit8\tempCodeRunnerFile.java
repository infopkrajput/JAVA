public class tempCodeRunnerFile {
    void getName() {
        // placeholder
    }

    public static void main(String[] args) {
        // placeholder main
    }
}