# MCA 
This Directory is had all the codes and assignments done during MCA course.