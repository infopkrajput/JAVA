public class replace {
    public static void main(String[] args) {
        String s = "Hello";
        System.out.println(s);
        // Replace 'l' with 'w' in the string
        String n = s.replace('l', 'w');
        System.out.println(n);
    }    
}
